<footer class="footer navbar-fixed-bottom footer-dark navbar-border">
      <p class="clearfix text-muted text-sm-center mb-0 px-2">
      		<span class="float-md-left d-xs-block d-md-inline-block">Copyright  &copy; {{date('Y')}} <a href="http://neutrix.systems" target="_blank" class="text-bold-800 grey darken-2">Neutrix </a>, All rights reserved. </span>

      		<span class="float-md-right d-xs-block d-md-inline-block">Powered By <a href="http://neutrix.systems" target="_blank" class="text-bold-800 grey darken-2">Neutrix.Systems </a> </span>
      </p>


</footer>